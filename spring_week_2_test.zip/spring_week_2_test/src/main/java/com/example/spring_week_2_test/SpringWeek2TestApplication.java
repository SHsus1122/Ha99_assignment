package com.example.spring_week_2_test;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringWeek2TestApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringWeek2TestApplication.class, args);
    }

}
